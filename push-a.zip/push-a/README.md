# ES_Theme_Pixel-Metadata
Pixel theme with changes made to include metadata.
Do not modify this theme or use graphics in other projects.
