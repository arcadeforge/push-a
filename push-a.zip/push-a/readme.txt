Theme 'pixel' Meta-data Edition v1.12 - 01-05-2017 by Rookervik

Thanks to muriani for the super-sexy Sega CD logo! 
Thanks to Omnija for helping me fix some code errors.


Updates:
- September 1st, 2016: Added TI-99/4A.
- August 22nd, 2016: Added TRS-80.
- May 29th, 2016: Added AGS, Steam, and Desktop systems.
- April  3rd, 2016: Added support for Pipplware.
- September 1st, 2016: Added TI-99/4A.
- October 25th, 2016: Added European/Japanese Super Nintendo.
- October 26th, 2016: Added SNK MVS and PC Engine CD-ROM. Renamed pcecd to pce-cd and tg16 to tg-16.
- October 30th, 2016: Set up metadata for this theme. Original Pixel theme not affected.
- November 9th, 2016: Added Stratagus, SuperGrafx, Oric, Channel F, Mega-CD, and BBC Micro.
- January 3rd, 2016: Added Macintosh Plus/SE, Updated logo graphics, changed license
- January 5th, 2016: Added Megadrive 32x, snesEU, Mega-CD, PC-FX.



License
=======
DO NOT modify this theme or use any assets in other themes or projects.
Graphics Copyright �2017 Eric Hettervik

Note: MetaPixel author asked for permission to use assets and was given permission, however: 
New Logos and graphics added on or after 01/02/2017 may not be used.

LOGO NOTICE:
The used logos and trademarks are copyright of their respective owners.